# JDK Fix Checklist

This checklist contains exact commands and steps (Windows `cmd.exe`) you can copy-paste to diagnose and fix the "Invalid jdkhome specified" error shown in your screenshot.

---

## Quick diagnosis
Run these in `cmd.exe` (open as normal user first):

```bat
:: Check whether the expected folder exists
dir "C:\Java\jdk-17"
:: Check whether java.exe exists there
dir "C:\Java\jdk-17\bin\java.exe"

:: Check java on PATH
java -version
where java

:: List common JDK locations
dir "C:\Program Files\Java"
dir "%ProgramFiles(x86)%\Java"
```

If the `dir` of `C:\Java\jdk-17` fails (says File Not Found), then no JDK is installed at that path.

---

## Option A — Install JDK to the expected path `C:\Java\jdk-17`
1. Download a JDK 17 (Eclipse Temurin / Adoptium recommended): https://adoptium.net/ — choose `OpenJDK 17` for Windows x64.
2. During the installer choose a **custom** install path and set it to: `C:\Java\jdk-17` (or extract a ZIP to that exact path).
3. Verify in `cmd.exe`:

```bat
"C:\Java\jdk-17\bin\java" -version
"C:\Java\jdk-17\bin\javac" -version
```

If they print versions, restart your IDE and the error should disappear.

---

## Option B — Point the IDE to an existing JDK
If you already have a JDK installed (example `C:\Program Files\Java\jdk-17.0.8`), point your IDE to that location.

NetBeans (example) — edit `netbeans.conf`:
- File: `<netbeans_install_dir>\etc\netbeans.conf`
- Find or add the line:

```conf
netbeans_jdkhome="C:\Program Files\Java\jdk-17.0.8"
```

Eclipse — edit `eclipse.ini` (add `-vm` before `-vmargs`):

```ini
-vm
C:/Program Files/Java/jdk-17.0.8/bin/javaw.exe
# ... rest of eclipse.ini
-vmargs
```

IntelliJ IDEA — either:
- File → Project Structure → SDKs → Add JDK → point to the JDK folder, or
- Help → Find Action → `Switch Boot JDK` to change the IDE runtime.

VS Code (Java extension) — in User settings JSON:
```json
"java.home": "C:\\Program Files\\Java\\jdk-17.0.8"
```

After changing the IDE config, restart the IDE.

---

## Option C — Set JAVA_HOME and PATH (system-wide)
Prefer using the Windows GUI (System → Advanced system settings → Environment Variables). If you want `cmd` commands, run as Administrator:

```bat
:: Replace path with the actual JDK you have
setx JAVA_HOME "C:\Program Files\Java\jdk-17.0.8" /M
:: Add JAVA_HOME\bin to system PATH (careful: setx truncates very long PATHs)
setx PATH "%PATH%;%JAVA_HOME%\bin" /M
```

Notes:
- `setx` writes a permanent environment variable but the change only applies to new processes.
- Because `setx` copies the current PATH into the new value, using it repeatedly can accidentally truncate PATH because of length limits. Prefer editing PATH via the GUI.

Verify:
```bat
java -version
javac -version
```

Then restart your IDE.

---

## If the dialog offers a fallback: try it
The screenshot asks: `Do you want to try to use default version?` — clicking **Yes** will let the IDE use another installed JDK (if one exists). If that works, afterwards change the IDE settings to point permanently to the working JDK.

---

## If you want to keep `C:\Java\jdk-17` but installation can't run there
You can install to `C:\Program Files\Java\jdk-17.0.x` and then create a directory junction so `C:\Java\jdk-17` points to it (run as Administrator):

```bat
mklink /J "C:\Java\jdk-17" "C:\Program Files\Java\jdk-17.0.8"
```

This makes `C:\Java\jdk-17` resolve to the actual installed folder.

---

## Verification checklist (after changes)
Run these commands and confirm the version outputs:

```bat
java -version
javac -version
where java
```

If those produce valid versions and the IDE still complains, check IDE config again and restart.

---

## If you tell me which IDE produced the dialog (NetBeans/Eclipse/IntelliJ/Other)
I can add an exact edit snippet for that IDE's config file and create the necessary `netbeans.conf` / `eclipse.ini` patch example.

---

## Quick summary of pick-a-fix
- Easiest: install JDK to `C:\Java\jdk-17` (Option A). 
- If JDK already exists: point IDE to it (Option B). 
- For system-wide fixes: set `JAVA_HOME` and `PATH` (Option C).


---

If you want, I can also:
- create a `netbeans.conf` snippet or `eclipse.ini` patch for you to paste, or
- create the junction (`mklink`) command and add it here ready to run (tell me the actual installed JDK folder).

