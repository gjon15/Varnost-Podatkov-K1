package fri.vp;

import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Signature;

import fri.isp.Agent;

public class RSASignatureExample {

    public static void main(String[] args) throws Exception {
        final byte[] document = "An example document".getBytes(StandardCharsets.UTF_8);
        final KeyPair key = KeyPairGenerator.getInstance("RSA").generateKeyPair(); // Generiraj ključni par

        // Podpiši dokument
        final Signature signer = Signature.getInstance("SHA256WithRSA"); // Uporabi RSA s SHA-256
        signer.initSign(key.getPrivate());
        signer.update(document); // Dodaj dokument k podpisu
        final byte[] signature = signer.sign(); // Ustvari podpis
        System.out.println("Signature: " + Agent.hex(signature));

        // Naredimo verifier za preverjanje podpisa
        final Signature verifier = Signature.getInstance("SHA256WithRSA"); // Uporabi RSA s SHA-256
        verifier.initVerify(key.getPublic());
        verifier.update(document); // Dodaj dokument k preverjanju

        // Preveri podpis
        if (verifier.verify(signature)) {
            System.out.println("Valid signature.");
        } else {
            System.err.println("Invalid signature.");
        }
    }
}
