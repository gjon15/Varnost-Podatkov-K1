package fri.vp;

import java.util.HexFormat;

public class FibTOTP {
    public static void main(String[] args) {
        // Uporabite spodnji ključ
        final byte[] key = HexFormat.of().parseHex("581f22628ce7b73da43abfceb41c94a5");

        int time = (int) (System.currentTimeMillis() / 1000L);
        int timestep = 30;
        long t = time / timestep;
        try {
            String otp = FibHOTP.HOTP(key, t, 6);
            System.out.println("Current TOTP: " + otp);
        } catch (Exception e) {
            System.err.println("Error generating TOTP: " + e.getMessage());
        }
        // Implementirajte program, ki vrača enkratna gesla izračunana iz časa
        // Lahko uporabite funkcijo System.currentTimeMillis(), a časovno vrednost
        // ustrezno popravite, da bo vsebovala sekunde
        // interval naj bo dolg 30 sekund, geslo pa 6 mest
        // Izpišite ga na standardni zaslon
    }
}