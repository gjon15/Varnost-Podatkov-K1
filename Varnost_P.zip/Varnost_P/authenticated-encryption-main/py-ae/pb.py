import json
from getpass import getpass
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os

file_path = "../data/phonebook.bin"

SALT_SIZE = 16
IV_SIZE = 16
KEY_LEN = 32  # AES-256
PBKDF2_ITER = 200_000


def derive_key(password: str, salt: bytes) -> bytes:
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.backends import default_backend

    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=KEY_LEN,
        salt=salt,
        iterations=PBKDF2_ITER,
        backend=default_backend()
    )
    return kdf.derive(password.encode("utf8"))

def load_phone_book(password: str,file: str) -> dict[str, str]:
    try:
        with open(file, 'br') as h:
            data = h.read()
    except (FileNotFoundError, json.JSONDecodeError):
        print(f"Could not load {file}, creating an empty phone book.")
        return {}
    
    if len(data) < (SALT_SIZE + IV_SIZE + 1):
        print(f"File {file} is corrupted or too small, creating an empty phone book.")
        return {}

    salt = data[:SALT_SIZE]
    iv = data[SALT_SIZE:SALT_SIZE + IV_SIZE]
    ciphertext = data[SALT_SIZE + IV_SIZE:]
    
    try:
        key = derive_key(password, salt)
        aesgcm = AESGCM(key)
        pt = aesgcm.decrypt(iv, ciphertext, None)
        return json.loads(pt.decode("utf8"))
    except Exception as e:
        print(f"Decryption failed: {e}. Creating an empty phone book.")
        return {}
    
    
def save_phone_book(phone_book: dict[str, str], file: str, password: str) -> None:
    pt = json.dumps(phone_book).encode("utf8")
    
    salt = os.urandom(SALT_SIZE)
    iv = os.urandom(IV_SIZE)
    key = derive_key(password, salt)
    aesgcm = AESGCM(key)
    ct = aesgcm.encrypt(iv, pt, None)    
    
    
    with open(file, 'wb') as h:
        h.write(salt + iv + ct)


def add_contact(phone_book, name, number):
    phone_book[name] = number
    print(f'Contact {name} added with number {number}.')


def search_contact(phone_book, query):
    hits = [(name, number) for name, number in phone_book.items() if name.find(query) != -1]

    if hits:
        print(f"Found {len(hits)} hits:")
        for name, number in hits:
            print(f"- {name}: {number}")
    else:
        print(f"No entries for query '{query}'")


def main():
    # Za vnos gesla uporabimo modul getpass
    password = getpass("Vpiši geslo: ")
    phone_book = load_phone_book(password, file_path)

    print(f"Found {len(phone_book)} contacts.")

    while True:
        print("\nPhone Book Menu:")
        print("1. Add Contact")
        print("2. Search Contact")
        print("3. Exit")

        choice = input("Enter your choice (1/2/3): ")

        match choice:
            case '1':
                name = input("Enter contact name: ")
                number = input("Enter contact number: ")
                add_contact(phone_book, name, number)
            case '2':
                name = input("Enter contact name to search: ")
                search_contact(phone_book, name)
            case '3':
                save_phone_book(phone_book, file_path, password)
                print("Phone book saved. Goodbye!")
                break
            case _:
                print("Invalid choice. Please enter 1, 2, or 3.")


if __name__ == "__main__":
    main()
