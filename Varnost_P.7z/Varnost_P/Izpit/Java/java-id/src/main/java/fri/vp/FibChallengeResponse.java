package fri.vp;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class FibChallengeResponse {
    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeyException {
        try {
            //Ključ
            final byte[] key = HexFormat.of().parseHex("581f22628ce7b73da43abfceb41c94a5");

            String challenge = System.console().readLine("Vnesite poziv (6-mestno število): ").trim();
            String response = hmacSha256Hex(key, challenge);
            System.out.println(response);

        } catch (Exception e) {
            System.err.println("Napaka pri generiranju odziva: " + e.getMessage());
        }
        //String response = OTP.fibOtp(key, n);
        //System.out.print(response);
        // S standardnega vhoda preberite poziv (to bo 6-mestno število)
        // izračunajte odziv s pomočjo ustrezne funkcije v razredu OTP
        // odziv izpišite na standardni izhod
    }

    private static String hmacSha256Hex(byte[] key, String message) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        SecretKeySpec keySpec = new SecretKeySpec(key, "HmacSHA256");
        mac.init(keySpec);
        byte[] hmac = mac.doFinal(message.getBytes(StandardCharsets.UTF_8));

        return HexFormat.of().formatHex(hmac);
    }    
}