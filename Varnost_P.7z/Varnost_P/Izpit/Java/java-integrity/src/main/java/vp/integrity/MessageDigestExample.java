package vp.integrity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HexFormat;

public class MessageDigestExample {

    public static void main(String[] args) throws NoSuchAlgorithmException {
        final String message = "Moje sporočilo";
        final byte[] pt = message.getBytes(StandardCharsets.UTF_8);

        // Izberemo ustrezno zgoščevalno funkcijo. Seznam veljavnih imen algoritmov najdemo v dokumentaciji
        final MessageDigest algorithm = MessageDigest.getInstance("SHA3-256");
    

        algorithm.update(pt);   // dodamo čistopis
        final byte[] hashed = algorithm.digest();   // zaključimo zgoščevanje

        System.out.printf("Sporočilo: %s%n", new String(pt, StandardCharsets.UTF_8));   // pretvorba iz byte[] v String
        System.out.printf("Zgostitev (šestnajstiško): %s%n", HexFormat.of().formatHex(hashed)); // pretvorba v šestajstiški niz
        // izpis kot polje bajtov (v javi se bajti predstavijo s predznakom)
        System.out.printf("Zgostitev (polje bajtov): %s%n", Arrays.toString(hashed));
    }
}
