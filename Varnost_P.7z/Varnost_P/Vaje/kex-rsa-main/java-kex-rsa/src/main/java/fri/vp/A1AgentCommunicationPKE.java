//Uporabite podlaganje OAEP s SHA-256 ter MGF1.
package fri.vp;

import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;

import javax.crypto.Cipher;

import fri.isp.Agent;
import fri.isp.Environment;

public class A1AgentCommunicationPKE {

    public static void main(String[] args) throws Exception {

        final Environment env = new Environment();

        // Uporabite podlaganje OAEP s SHA-256 ter MGF1.
        final String algorithm = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";
        final KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA"); // Generiramo ključni par za Bor-a
        kpg.initialize(2048); // Velikost ključa 2048 bitov (Prevzepo pri RSA)
        final KeyPair borKP = kpg.generateKeyPair();

        env.add(new Agent("ana") {
            @Override
            public void task() throws Exception {
                final String message = "Pozdravljen, Bor!";  // Sporočilo, ki ga želimo poslati Bor-u
                final byte[] pt = message.getBytes(StandardCharsets.UTF_8); // Pretvorimo sporočilo v bajtno obliko

                System.out.println("Message: " + message);
                System.out.println("PT: " + Agent.hex(pt));

                // Šifriramo sporočilo z javnim ključem Bor-a
                final Cipher rsaEnc = Cipher.getInstance(algorithm);
                rsaEnc.init(Cipher.ENCRYPT_MODE, borKP.getPublic()); // Uporabimo javni ključ Bor-a za šifriranje
                final byte[] ct = rsaEnc.doFinal(pt); // Šifrirano besedilo

                System.out.println("CT: " + Agent.hex(ct));
                send("bor", ct);
            }
        });

        env.add(new Agent("bor") {
            @Override
            public void task() throws Exception {
                byte[] ct = receive("ana"); // Prejmemo šifrirano sporočilo od Ane

                // Dešifriramo sporočilo z zasebnim ključem Bor-a
                final Cipher rsaDec = Cipher.getInstance(algorithm);
                rsaDec.init(Cipher.DECRYPT_MODE, borKP.getPrivate());
                final byte[] decryptedText = rsaDec.doFinal(ct);

                System.out.println("PT: " + Agent.hex(decryptedText));
                final String message2 = new String(decryptedText, StandardCharsets.UTF_8);
                System.out.println("Message: " + message2);
            }
        });

        env.connect("ana", "bor");
        env.start();
    }
}
