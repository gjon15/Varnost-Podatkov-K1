//Implementirajte nalogo A2AgentCommunicationPKEKeyExchange.java,
// kjer se Ana in Bor najprej dogovorita o ključu z uporabo asimetrične
// šifre RSA/ECB/OAEPWithSHA-256AndMGF1Padding,
// zatem pa Ana Boru pošlje sporočilo, ki je šifrirano z AES-GCM.
package fri.vp;

import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.MGF1ParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import javax.crypto.spec.SecretKeySpec;

import fri.isp.Agent;
import fri.isp.Environment;

public class A2AgentCommunicationPKEKeyExchange {

    public static void main(String[] args) throws Exception {
        final Environment env = new Environment();

        // Priprava ključnega para za Bora
        final String algorithm = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";
        final KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        final KeyPair borKP = kpg.generateKeyPair();

        // Parametri za OAEP (RSA naredimo bolj varnega)
        final OAEPParameterSpec oaepSpec
                = new OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT);

        env.add(new Agent("ana") {
            @Override
            public void task() throws Exception {
                // Generiranje AES ključa
                KeyGenerator kG = KeyGenerator.getInstance("AES");
                kG.init(128);
                SecretKey aesKey = kG.generateKey();

                // Šifriranje AES ključa z Borovim javnim ključem
                Cipher rsaEnc = Cipher.getInstance(algorithm);  // RSA/ECB/OAEPWithSHA-256AndMGF1Padding
                PublicKey borP = borKP.getPublic();
                rsaEnc.init(Cipher.ENCRYPT_MODE, borP, oaepSpec); // Inicializacija za šifriranje
                byte[] eAesK = rsaEnc.doFinal(aesKey.getEncoded()); // Šifriranje AES ključa
                send("bor", eAesK);

                // Šifriranje sporočila z AES-GCM
                final String message = "Pozdravljen, Bor!";
                final byte[] pt = message.getBytes(StandardCharsets.UTF_8);

                // Generiranje naključnega IV
                byte[] iv = new byte[12];
                SecureRandom rnd = new SecureRandom();
                rnd.nextBytes(iv);

                // Šifriranje s AES-GCM
                Cipher gcmEnc = Cipher.getInstance("AES/GCM/NoPadding");
                GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv); // 128-bitni avtentikacijski tag
                gcmEnc.init(Cipher.ENCRYPT_MODE, aesKey, gcmSpec);  // Inicializacija za šifriranje
                byte[] ct = gcmEnc.doFinal(pt);

                System.out.println("CT: " + Agent.hex(ct));
                System.out.println("IV: " + Agent.hex(iv));
                send("bor", iv);
                send("bor", ct);
            }
        });

        env.add(new Agent("bor") {
            @Override
            public void task() throws Exception {
                byte[] encAesKey = (byte[]) receive("ana");

                // Dešifriranje AES ključa z Borovim zasebnim ključem
                Cipher rsaDec = Cipher.getInstance(algorithm);
                rsaDec.init(Cipher.DECRYPT_MODE, borKP.getPrivate(), oaepSpec);
                byte[] aesKeyBytes = rsaDec.doFinal(encAesKey);

                // Obnovitev AES ključa
                SecretKey aesKey = new SecretKeySpec(aesKeyBytes, "AES");

                byte[] iv = (byte[]) receive("ana");
                byte[] ct = (byte[]) receive("ana");

                // Dešifriranje sporočila z AES-GCM
                Cipher gcmDec = Cipher.getInstance("AES/GCM/NoPadding");
                GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv); // 128-bitni avtentikacijski tag
                gcmDec.init(Cipher.DECRYPT_MODE, aesKey, gcmSpec); // Inicializacija za dešifriranje
                byte[] decryptedText = gcmDec.doFinal(ct);

                String recoveredText = new String(decryptedText, StandardCharsets.UTF_8);
                System.out.println("PT: " + Agent.hex(decryptedText));
                System.out.println("Message: " + recoveredText);
            }
        });

        env.connect("ana", "bor");
        env.start();
    }
}
