package fri.vp;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.interfaces.XECPublicKey;
import java.security.spec.NamedParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import fri.isp.Agent;
import fri.isp.Environment;

public class A3AgentCommunicationXDHKeyExchange {

    public static void main(String[] args) {

        final Environment env = new Environment();

        env.add(new Agent("ana") {
            @Override
            public void task() throws Exception {
                // Ustvari svoj ključni par
                final KeyPairGenerator kpg = KeyPairGenerator.getInstance("XDH");
                kpg.initialize(new NamedParameterSpec("X25519")); // Uporabi eliptično krivuljo X25519 ali X448
                final KeyPair kp = kpg.generateKeyPair();

                // Pošlji svoj javni ključ Boru
                send("bor", kp.getPublic().getEncoded());
                print("My contribution: A = g^a = %s",
                        hex(kp.getPublic().getEncoded()));

                // Prejmi Borov javni ključ
                final byte[] bobPubEnc = receive("bor");

                // Ustvari specifikacijo javnega ključa iz bajtov
                final X509EncodedKeySpec keySpec = new X509EncodedKeySpec(bobPubEnc);

                // Ustvari Borov javni ključ iz specifikacije
                XECPublicKey bobPub = (XECPublicKey) KeyFactory.getInstance("XDH").generatePublic(keySpec);
                print("Ana: received Bor public (len=%d): %s", bobPubEnc.length, hex(bobPubEnc));

                // Izračunaj skupni skrivni ključ
                final KeyAgreement xdh = KeyAgreement.getInstance("XDH");
                xdh.init(kp.getPrivate());
                xdh.doPhase(bobPub, true);

                // Generiraj skupni skrivni ključ
                final byte[] sharedS = xdh.generateSecret();
                print("Shared secret: g^ab = B^a = %s", hex(sharedS));

                // Izvedi odvod ključa z uporabo SHA-256 in vzemi prvih 16 bajtov za AES-128 ključ
                MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
                byte[] derivedKey = sha256.digest(sharedS); // Hashiraj skupni skrivni ključ

                byte[] aesKeyB = Arrays.copyOf(derivedKey, 16); // Prvih 16 bajtov za AES-128
                SecretKey aesKey = new SecretKeySpec(aesKeyB, "AES"); // Ustvari AES ključ

                print("Ana: derived AES-128 key: %s", hex(aesKeyB)); // Izpiši izpeljani ključ

                final String message = "Pozdravljen, Bor!";
                final byte[] pt = message.getBytes(StandardCharsets.UTF_8);

                // Izračun naključnega IV za AES-GCM
                byte[] iv = new byte[12];
                new SecureRandom().nextBytes(iv);

                // Šifriraj sporočilo z AES-GCM
                Cipher gcmEnc = Cipher.getInstance("AES/GCM/NoPadding");
                GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv);
                gcmEnc.init(Cipher.ENCRYPT_MODE, aesKey, gcmSpec);
                byte[] ct = gcmEnc.doFinal(pt);

                send("bor", iv);
                send("bor", ct);
            }
        });

        env.add(new Agent("bor") {
            @Override
            public void task() throws Exception {

                // Prejmi Anin javni ključ
                final byte[] alicePubEnc = (byte[]) receive("ana");

                // Ustvari Anin javni ključ iz bajtov
                final X509EncodedKeySpec aliceSpec = new X509EncodedKeySpec(alicePubEnc);
                final XECPublicKey alicePub = (XECPublicKey) KeyFactory.getInstance("XDH").generatePublic(aliceSpec);
                print("Bor: received Ana public (len=%d): %s", alicePubEnc.length, hex(alicePubEnc));

                // Ustvari svoj ključni par
                final KeyPairGenerator kpg = KeyPairGenerator.getInstance("XDH");
                kpg.initialize(new NamedParameterSpec("X448")); // Uporabi eliptično krivuljo X448
                final KeyPair kp = kpg.generateKeyPair();

                // Pošlji svoj javni ključ Ani
                send("ana", kp.getPublic().getEncoded());
                print("Bor: sent public (len=%d): %s", kp.getPublic().getEncoded().length, hex(kp.getPublic().getEncoded()));

                // Izračunaj skupni skrivni ključ
                final KeyAgreement ka = KeyAgreement.getInstance("XDH");
                ka.init(kp.getPrivate());   // Bor uporabi svoj zasebni ključ
                ka.doPhase(alicePub, true); // Anin javni ključ
                final byte[] shared = ka.generateSecret(); // Skupni skrivni ključ
                print("Bor: raw shared secret (%d): %s", shared.length, hex(shared)); // Izpiši skupni skrivni ključ

                MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
                byte[] hashed = sha256.digest(shared);
                byte[] aesKeyBytes = Arrays.copyOf(hashed, 16);
                SecretKey aesKey = new SecretKeySpec(aesKeyBytes, "AES");
                print("Bor: derived AES-128 key: %s", hex(aesKeyBytes));

                byte[] iv = (byte[]) receive("ana");
                byte[] ct = (byte[]) receive("ana");
                print("Bor: received IV(%d) CT(%d)", iv.length, ct.length);

                Cipher gcmDec = Cipher.getInstance("AES/GCM/NoPadding");
                GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv);
                gcmDec.init(Cipher.DECRYPT_MODE, aesKey, gcmSpec);
                byte[] pt = gcmDec.doFinal(ct);

                String recovered = new String(pt, StandardCharsets.UTF_8);
                print("Bor: recovered plaintext: %s", recovered);
            }
        });

        env.connect("ana", "bor");
        env.start();
    }
}
