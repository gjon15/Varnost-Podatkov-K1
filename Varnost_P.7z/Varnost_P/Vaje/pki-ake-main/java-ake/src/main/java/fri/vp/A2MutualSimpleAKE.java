package fri.vp;

import java.security.cert.X509Certificate;

import fri.isp.Agent;
import fri.isp.Environment;
import static fri.vp.CertUtils.certFromFile;

public class A2MutualSimpleAKE {

    public static void main(String[] args) throws Exception {

        final Environment env = new Environment();

        // certifikat CA uporabite kot globalno spremenljivko
        final X509Certificate certCA = certFromFile("../cert_ca.pem");

        env.add(new Agent("ana") {
            @Override
            public void task() throws Exception {
                final X509Certificate certBor = certFromFile("../cert_bor.pem"); // naložimo Borov certifikat
                String subject = certBor.getSubjectX500Principal().getName();
                if (!subject.contains("CN=Bor")) {      // preverimo, ali je certifikat res od Bora
                    throw new SecurityException("Ana: Bor nima certifikata!");
                }
                certBor.checkValidity();               // preverimo veljavnost certifikata (časovno)
                certBor.verify(certCA.getPublicKey()); // preverimo, ali je certifikat podpisal CA

                System.out.println("Ana: Certifikat od Bora je veljaven.");

            }
        });

        env.add(new Agent("bor") {
            @Override
            public void task() throws Exception {
                final X509Certificate certAna = certFromFile("../cert_ana.pem"); // naložimo Anin certifikat
                String subject = certAna.getSubjectX500Principal().getName();
                if (!subject.contains("CN=Ana")) {      // preverimo, ali je certifikat res od Ane
                    throw new SecurityException("Bor: Ana nima certifikata!");
                }
                certAna.checkValidity();               // preverimo veljavnost certifikata (časovno)
                certAna.verify(certCA.getPublicKey()); // preverimo, ali je certifikat podpisal CA

                System.out.println("Bor: Certifikat od Ane je veljaven.");

            }
        });

        env.connect("ana", "bor");
        env.start();
    }
}
