package fri.vp;

import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;

import fri.isp.Agent;
import fri.isp.Environment;
import static fri.vp.CertUtils.certFromFile;
import static fri.vp.CertUtils.privateKeyFromFile;

public class A1OneSidedSimpleAKE {

    public static void main(String[] args) throws Exception {

        final Environment env = new Environment();

        // certifikat CA uporabite kot globalno spremenljivko
        final X509Certificate certCA = certFromFile("../cert_ca.pem");

        env.add(new Agent("ana") {
            @Override
            public void task() throws Exception {

                // naložimo Borov certifikat
                byte[] received = receive("bor");
                final X509Certificate certBor = (X509Certificate) CertUtils.certFromBytes(received);

                String subject = certBor.getSubjectX500Principal().getName(); // pridobimo podatke o lastniku certifikata
                if (!subject.contains("CN=Bor")) {      // preverimo, ali je certifikat res od Bora
                    throw new SecurityException("Ana: Ni pravi sogovorec!");
                }
                certBor.checkValidity();               // preverimo veljavnost certifikata (časovno)
                certBor.verify(certCA.getPublicKey()); // preverimo, ali je certifikat podpisal CA

                System.out.println("Ana: Certifikat od Bora je veljaven.");
            }
        });

        env.add(new Agent("bor") {
            @Override
            public void task() throws Exception {
                final X509Certificate certBor = certFromFile("../cert_bor.pem");
                final RSAPrivateKey skBor = privateKeyFromFile("../sk_bor.pem");
                send("ana", certBor.getPublicKey().getEncoded()); // pošljemo svoj certifikat

            }
        });

        env.connect("ana", "bor");
        env.start();
    }
}
