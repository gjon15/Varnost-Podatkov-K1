package fri.vp;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import fri.isp.Agent;
import fri.isp.Environment;

public class A3MITMSimpleKE {

    public static void main(String[] args) throws Exception {
        final Environment env = new Environment();

        env.add(new Agent("ana") {
            @Override
            public void task() throws Exception {
                final KeyPair kp = KeyPairGenerator.getInstance("RSA").generateKeyPair();
                send("bor", kp.getPublic().getEncoded());

                // prejme šifriran AES ključ
                final Cipher rsa = Cipher.getInstance("RSA/ECB/OAEPPadding");
                rsa.init(Cipher.DECRYPT_MODE, kp.getPrivate());
                final byte[] keyBytes = rsa.doFinal(receive("bor"));
                final SecretKeySpec aesKey = new SecretKeySpec(keyBytes, "AES");

                final Cipher aes = Cipher.getInstance("AES/GCM/NoPadding");
                aes.init(Cipher.ENCRYPT_MODE, aesKey); // samodejno ustvari IV
                send("bor", aes.getIV());
                send("bor", aes.doFinal("Hello World!".getBytes(StandardCharsets.UTF_8)));
                print("Done!");
            }
        });

        env.add(new Agent("nandi") {
            @Override
            public void task() throws Exception {
                // V telesu te metode izvedite napad MITM na anonimni dogovor o ključu
                // med Ano in Borom. Pomagajte si z diagramom s prosojnic.
                // Implementacije Ane in Bora ne spreminjajte.

                // Prestrezanje Aninega RSA javnega ključa
                byte[] anaPubBytes = receive("ana");
                X509EncodedKeySpec anaSpec = new X509EncodedKeySpec(anaPubBytes);
                KeyFactory kf = KeyFactory.getInstance("RSA");
                PublicKey anaPK = kf.generatePublic(anaSpec);

                //Ustvari Nandijev lastni RSA par
                KeyPair nandiKP = KeyPairGenerator.getInstance("RSA").generateKeyPair();

                //Bor dobi Nandijev javni ključ namesto Aninega
                send("bor", nandiKP.getPublic().getEncoded());

                //Prestrezanje Borovega AES ključa (šifriran z Nandijevim javnim ključem)
                byte[] encAES = receive("bor");

                Cipher rsa = Cipher.getInstance("RSA/ECB/OAEPPadding");
                rsa.init(Cipher.DECRYPT_MODE, nandiKP.getPrivate());
                byte[] aesKeyBytes = rsa.doFinal(encAES);

                SecretKeySpec aesKey = new SecretKeySpec(aesKeyBytes, "AES");
                print("Nandi: ukradel sem AES ključ!");

                //Ponovno šifriraj AES ključ z Aninim pravim javnim ključem
                rsa.init(Cipher.ENCRYPT_MODE, anaPK);
                send("ana", rsa.doFinal(aesKeyBytes));

                //Posreduj IV
                byte[] iv = receive("ana");
                send("bor", iv);

                //Prestrezanje in dešifriranje sporočila
                byte[] ciphertext = receive("ana");

                Cipher aes = Cipher.getInstance("AES/GCM/NoPadding");
                aes.init(Cipher.DECRYPT_MODE, aesKey, new GCMParameterSpec(128, iv));
                byte[] plaintext = aes.doFinal(ciphertext);
                print("Nandi prebral: %s", new String(plaintext, StandardCharsets.UTF_8));

                //Pošlji Boru, da se ne zruši protokol
                send("bor", ciphertext);
            }
        });

        env.add(new Agent("bor") {
            @Override
            public void task() throws Exception {
                // prejme Anin javni ključ
                final X509EncodedKeySpec keySpec = new X509EncodedKeySpec(receive("ana"));
                final KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                final PublicKey anaPK = keyFactory.generatePublic(keySpec);

                // ustvari naključni AES ključ
                final SecretKey key = KeyGenerator.getInstance("AES").generateKey();

                final Cipher rsa = Cipher.getInstance("RSA/ECB/OAEPPadding");
                rsa.init(Cipher.ENCRYPT_MODE, anaPK);
                send("ana", rsa.doFinal(key.getEncoded()));

                // prejme šifrirano sporočilo
                final Cipher aes = Cipher.getInstance("AES/GCM/NoPadding");
                aes.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, receive("ana")));
                print("Got: %s", new String(aes.doFinal(receive("ana")), StandardCharsets.UTF_8));
            }
        });

        env.mitm("ana", "bor", "nandi");
        env.start();
    }
}
