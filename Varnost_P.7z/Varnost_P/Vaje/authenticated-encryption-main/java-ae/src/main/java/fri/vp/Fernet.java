package fri.vp;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.Key;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Fernet {

    public static byte[] genKey() throws Exception {
        final byte[] key = new byte[32];
        SecureRandom.getInstanceStrong().nextBytes(key);
        return Base64.getUrlEncoder().withoutPadding().encode(key);
    }

    public static byte[] decrypt(byte[] key, byte[] token) throws Exception {
        final byte[] decodetKey = Base64.getUrlDecoder().decode(key);
        final Key macKey = new SecretKeySpec(Arrays.copyOfRange(decodetKey, 0, 16), "HmacSHA256");
        final Key aesKey = new SecretKeySpec(Arrays.copyOfRange(decodetKey, 16, 32), "AES");

        final byte[] decodedCt = Base64.getUrlDecoder().decode(token);
        final ByteBuffer buff = ByteBuffer.wrap(decodedCt);

        // preveri verzijo
        final byte version = buff.get();
        if (version != (byte) 128) {
            System.out.println("Unsupported version: " + version);
            System.exit(1);
        }
        // preveri datum/cas
        final long timestamp = buff.getLong();
        System.out.println("Timestamp: " + timestamp * 1000);

        // IV
        final byte[] iv = new byte[16];
        buff.get(iv, 0, 16);

        // CT
        final byte[] ct = new byte[buff.remaining() - 32];
        buff.get(ct, 0, ct.length);

        // HMAC tag
        final byte[] tag = new byte[32];
        buff.get(tag, 0, 32);

        // preveri HMAC
        final Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(macKey);
        final byte[] recomputed = mac.doFinal(Arrays.copyOfRange(decodedCt, 0, decodedCt.length - 32));

        if (!MessageDigest.isEqual(tag, recomputed)) {
            System.out.println("HMAC verification failed!");
            System.exit(1);
        }

        final Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, aesKey, new IvParameterSpec(iv));
        final byte[] pt = cipher.doFinal(ct);
        System.out.println("Decryption successful!");

        return pt;
    }

    public static byte[] encrypt(byte[] key, byte[] pt) throws Exception {
        final byte[] decodetKey = Base64.getUrlDecoder().decode(key);
        final Key macKey = new SecretKeySpec(Arrays.copyOfRange(decodetKey, 0, 16), "HmacSHA256");
        final Key aesKey = new SecretKeySpec(Arrays.copyOfRange(decodetKey, 16, 32), "AES");

        // verzija
        final byte version = (byte) 128;

        // timestamp
        final byte[] timestamp = ByteBuffer.allocate(8).putLong(System.currentTimeMillis() / 1000).array();

        // IV
        final byte[] iv = new byte[16];
        SecureRandom.getInstanceStrong().nextBytes(iv);

        // AES-CBC
        final Cipher aes = Cipher.getInstance("AES/CBC/PKCS5Padding");
        aes.init(Cipher.ENCRYPT_MODE, aesKey, new IvParameterSpec(iv));
        final byte[] ct = aes.doFinal(pt);

        // HMAC tag
        final Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(macKey);
        mac.update(version);
        mac.update(timestamp);
        mac.update(iv);
        mac.update(ct);
        final byte[] tag = mac.doFinal();

        final byte[] concatenated = ByteBuffer
                .allocate(1 + timestamp.length + iv.length + ct.length + tag.length)
                .put(version)
                .put(timestamp)
                .put(iv)
                .put(ct)
                .put(tag)
                .array();

        return Base64.getUrlEncoder().encode(concatenated);
    }

    public static void main(String[] args) throws Exception {
        try {
            final byte[] key = Files.readAllBytes(Path.of("Varnost_P\\authenticated-encryption-main\\fernet.key"));
            // final byte[] ct =
            // Files.readAllBytes(Path.of("Varnost_P\\authenticated-encryption-main\\fernet.ct"));
            final byte[] pt = "Dober dan, to je skrivno sporočilo!".getBytes(StandardCharsets.UTF_8);
            final byte[] ct = encrypt(key, pt);
            System.out.print(new String(ct, StandardCharsets.UTF_8));
            // final byte[] pt = decrypt(key, ct);
            // System.out.print(new String(pt, StandardCharsets.UTF_8));
            final byte[] dt = decrypt(key, ct);
            System.out.print(new String(dt, StandardCharsets.UTF_8));

            Files.write(Path.of("Varnost_P\\authenticated-encryption-main\\fernet-java.ct"), ct);
            Files.write(Path.of("Varnost_P\\authenticated-encryption-main\\fernet-java.key"), key);

        } catch (Exception e) {
            System.out.println("Napaka pri branju datotek ali dekripciji:");
            e.printStackTrace();
        }

    }

}
