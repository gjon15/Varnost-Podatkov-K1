package fri.vp;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class FibChallengeResponse {

    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeyException {
        try {
            final byte[] key = HexFormat.of().parseHex("581f22628ce7b73da43abfceb41c94a5");

            final String challengeStr = System.console().readLine("Vnesite poziv (6-mestno število): ").trim();

            final String response = hmacSha256Hex(key, challengeStr);
            System.out.println(response);

        } catch (Exception e) {
            System.err.println("Napaka pri generiranju odziva: " + e.getMessage());
        }
    }

    private static String hmacSha256Hex(byte[] key, String message) throws Exception { // Preverimo odziv na Strežniku
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(key, "HmacSHA256"));
        byte[] hmac = mac.doFinal(message.getBytes(StandardCharsets.UTF_8));
        return HexFormat.of().formatHex(hmac);
    }
}
