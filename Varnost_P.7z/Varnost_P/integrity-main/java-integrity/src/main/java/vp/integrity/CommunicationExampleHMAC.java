package vp.integrity;

import java.nio.charset.StandardCharsets;
import java.security.Key;

import javax.crypto.KeyGenerator;
import javax.crypto.Mac;

import fri.isp.Agent;
import fri.isp.Environment;

/**
 * To je primer simulacijskega okolja, v katerem si agenti (Ana, Bor, Cene,
 * Nandi idr.)
 * izmenjujejo sporočila.
 * <p>
 * Vsak agent se izvaja v svoji niti in neodvisno od ostalih. S pomočjo klicev
 * funkcije
 * `send(byte[])` in `byte[] receive(String)` agenti pošiljajo in prejemajo
 * sporočila.
 * <p>
 * Enota poslanega podatka je polje bajtov (byte[]), zato je treba vsak podatek
 * pred
 * pošiljanjem postrojiti.
 */
public class CommunicationExampleHMAC {
    public static void main(String[] args) throws Exception {

        // Simulacijsko okolje, v katerem bivajo agenti
        final Environment env = new Environment();

        final Key key = KeyGenerator.getInstance("HmacSHA3-256").generateKey();

        env.add(new Agent("ana") {
            @Override
            public void task() throws Exception {
                final Mac ana = Mac.getInstance("HmacSHA3-256");
                final byte[] pt = "Zdravo Bor, tukaj Ana.".getBytes(StandardCharsets.UTF_8);

                ana.init(key);
                ana.update(pt);

                send("bor", pt);
                send("bor", ana.doFinal());
                print("Poslala sem sporočilo.");
            }
        });

        env.add(new Agent("bor") {
            @Override
            public void task() throws Exception {
                // Bor prejme sporočilo

                final byte[] pt = receive("ana");
                final byte[] tag = receive("ana");

                final Mac bor = Mac.getInstance("HmacSHA3-256");
                bor.init(key);
                bor.update(pt);
                if (!java.util.Arrays.equals(tag, bor.doFinal())) {
                    print("Sporočilo je bilo spremenjeno, prekinitvam!");
                    System.exit(1);
                }

                // Bor sporočilo izpiše
                print("Sporočilo se glasi: '%s'", new String(pt, StandardCharsets.UTF_8));

            }
        });

        // Povežemo Ano in Bora
        env.connect("ana", "bor");
        // zaženemo simulacijsko okolje
        env.start();
    }
}
