package fri.vp;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;


public class FibHOTP {

    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeyException {
        // Uporabimo sledeč ključ (je zavoljo preprostopsti implementacije enak za vse uporabnike,
        // v produkciji mora imeti vsak uporabnik svojega)
        final byte[] key = HexFormat.of().parseHex("581f22628ce7b73da43abfceb41c94a5");
        for (int i = 0; i < 10; i++) {
            long counter = i;
            String otp = HOTP(key, counter, 6);
            System.out.println("Counter: " + counter + " OTP: " + otp);
        }
        
        // Ustvarite 10 enkratnih gesel za vrednosti med 0 in 10.
        // Gesla naj bodo 6-mestna, izračunana naj bodo s HMAC-SHA1.
        // Gesla izpišite na standardni izhod
        // Pri prijavi  v spletno aplikacijo morate
    }

    public static String HOTP(byte[] key, long counter, int digits) throws NoSuchAlgorithmException, InvalidKeyException {
        byte[] counterBytes = new byte[8];
        for (int i = 7; i >= 0; i--) {
            counterBytes[i] = (byte) (counter & 0xFF);
            counter >>= 8;
        }

        Mac mac = Mac.getInstance("HmacSHA1");
        SecretKeySpec keySpec = new SecretKeySpec(key, "HmacSHA1");
        mac.init(keySpec);
        byte[] hmac = mac.doFinal(counterBytes);

        int offset = hmac[hmac.length - 1] & 0x0F;
        int binary = ((hmac[offset] & 0x7f) << 24) |
                ((hmac[offset + 1] & 0xff) << 16) |
                ((hmac[offset + 2] & 0xff) << 8) |
                (hmac[offset + 3] & 0xff);

        int otp = binary % (int) Math.pow(10, digits);
        return String.format("%0" + digits + "d", otp);
    }

}



