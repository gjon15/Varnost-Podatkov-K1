package fri.vp;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class ECIESExample {

    public record Ciphertext(byte[] pk, byte[] iv, byte[] ct) {

    }

    // Generiranje para ključev X25519
    public static KeyPair gen() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("X25519");
        return kpg.generateKeyPair();
    }

    //----------------------------------------------------------------------------------------------------------
    // Šifriranje z ECIES
    public static Ciphertext encrypt(PublicKey pk, byte[] plaintext) throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("X25519"); // ephemeral key pair
        KeyPair ephemeral = kpg.generateKeyPair();
        PrivateKey b = ephemeral.getPrivate(); // ephemeral private
        PublicKey B = ephemeral.getPublic();  // ephemeral public

        // Skupni skrivni ključ
        KeyAgreement ka = KeyAgreement.getInstance("XDH"); // X25519 key agreement
        ka.init(b); // Anin ephemeral private key
        ka.doPhase(pk, true); // Borov javni ključ
        byte[] Z = ka.generateSecret(); // Skupna skrivnost

        // Ustvarimo simetrični ključ iz skupne skrivnosti
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        byte[] Kbytes = sha256.digest(Z); // 32 bytn ključ

        // Uporabimo ChaCha20 za simetrično šifriranje
        SecretKey K = new SecretKeySpec(Kbytes, "ChaCha20");
        byte[] iv = new byte[12]; // 12-byte nonce
        new SecureRandom().nextBytes(iv); // random nonce

        // Encrypt with ChaCha20-Poly1305
        Cipher cipher = Cipher.getInstance("ChaCha20-Poly1305"); // symmetric encryption
        IvParameterSpec ivSpec = new IvParameterSpec(iv); // nonce
        cipher.init(Cipher.ENCRYPT_MODE, K, ivSpec); // init cipher
        byte[] ct = cipher.doFinal(plaintext); // Tajnopis

        return new Ciphertext(B.getEncoded(), iv, ct);
    }
    //----------------------------------------------------------------------------------------------------------

    public static byte[] decrypt(PrivateKey sk, byte[] pk, byte[] iv, byte[] ct) throws Exception {
        // Bor prejme Anin javni ključ (pk), skupno skrivnost izračuna z lastnim zasebnim ključem (sk)

        // Ustvari javni ključ iz bytnov
        KeyFactory kf = KeyFactory.getInstance("X25519");
        PublicKey B = kf.generatePublic(new X509EncodedKeySpec(pk)); // Anin javni ključ

        // Derive shared secret
        KeyAgreement ka = KeyAgreement.getInstance("XDH");
        ka.init(sk);
        ka.doPhase(B, true);
        byte[] Z = ka.generateSecret(); // Skupna skrivnost

        // Derive symmetric key
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        byte[] Kbytes = sha256.digest(Z); // 32 bytn ključ
        SecretKey K = new SecretKeySpec(Kbytes, "ChaCha20"); // Bor dobi isti simetrični ključ

        Cipher cipher = Cipher.getInstance("ChaCha20-Poly1305"); // Decrypt with ChaCha20-Poly1305
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        cipher.init(Cipher.DECRYPT_MODE, K, ivSpec);

        return cipher.doFinal(ct);
    }
    //----------------------------------------------------------------------------------------------------------

    public static void main(String[] args) throws Exception {
        final String message = "A test message.";
        final byte[] pt = message.getBytes(StandardCharsets.UTF_8);

        final KeyPair borKP = gen(); // Bob's key pair

        // Save keys and message to files
        Files.write(Path.of("..\\ecies.pk"), borKP.getPublic().getEncoded());
        Files.write(Path.of("..\\ecies.sk"), borKP.getPrivate().getEncoded());
        Files.write(Path.of("..\\ecies.msg"), pt);

        // Encrypt message
        final Ciphertext ct = encrypt(borKP.getPublic(), pt); // dobimo tajnopis od Aninega zasebnega ključa in Borovega javnega ključa
        // Save ciphertext to file
        Files.write(Path.of("..\\ecies.ct"),
                ByteBuffer.allocate(ct.pk.length + ct.iv.length + ct.ct.length)
                        .put(ct.pk).put(ct.iv).put(ct.ct).array());

        // Decrypt message
        final byte[] dt = decrypt(borKP.getPrivate(), ct.pk, ct.iv, ct.ct);
        System.out.println(new String(dt, StandardCharsets.UTF_8));
    }
}
