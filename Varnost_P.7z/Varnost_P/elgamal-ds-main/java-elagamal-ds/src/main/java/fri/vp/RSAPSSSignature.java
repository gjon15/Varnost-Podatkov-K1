package fri.vp;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.PSSParameterSpec;

import fri.isp.Agent;

public class RSAPSSSignature {

    // Generiraj RSA ključni par
    public static KeyPair gen() throws Exception {
        KeyPairGenerator keyPar = KeyPairGenerator.getInstance("RSA");
        keyPar.initialize(2048, new SecureRandom());
        System.out.println(keyPar.getProvider());
        return keyPar.generateKeyPair();
    }

    // Podpiši sporočilo z RSAPSS
    public static byte[] sign(PrivateKey key, byte[] message) throws Exception {
        Signature signer = Signature.getInstance("RSASSA-PSS"); // Uporabi RSASSA-PSS
        // Nastavi parametre PSS
        signer.setParameter(new PSSParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA256, 32, 1));
        signer.initSign(key);
        signer.update(message);
        System.out.println("Signing message: " + new String(message, StandardCharsets.UTF_8));
        return signer.sign();
    }

    // Preveri podpis z RSAPSS
    public static boolean verify(PublicKey key, byte[] message, byte[] signature) throws Exception {
        Signature verifier = Signature.getInstance("RSASSA-PSS");
        // Nastavi parametre PSS
        PSSParameterSpec pssSpec = new PSSParameterSpec(
                "SHA-256",
                "MGF1",
                MGF1ParameterSpec.SHA256,
                32,
                1
        );
        verifier.setParameter(pssSpec); // Nastavi parametre PSS
        verifier.initVerify(key);
        verifier.update(message);
        System.out.println("Verifying message: " + new String(message, StandardCharsets.UTF_8));
        return verifier.verify(signature);
    }

    public static void main(String[] args) throws Exception {
        // Sporočilo za podpis
        final byte[] document = "We would like to sign this.".getBytes(StandardCharsets.UTF_8);

        // Generiraj ključni par
        final KeyPair key = gen();
        Files.write(Path.of("../rsa.pk"), key.getPublic().getEncoded()); // Shrani javni ključ
        Files.write(Path.of("../rsa.sk"), key.getPrivate().getEncoded()); // Shrani zasebni ključ

        // Podpiši in shrani podpis
        final byte[] signature = sign(key.getPrivate(), document);
        System.out.println("Signature: " + Agent.hex(signature));

        // Shrani podpis in sporočilo
        Files.write(Path.of("../rsa.sig"), signature);
        Files.write(Path.of("../rsa.msg"), document);

        // Preveri podpis
        if (verify(key.getPublic(), document, signature)) {
            System.out.println("Valid signature.");
        } else {
            System.err.println("Invalid signature.");
        }
    }
}
