package fri.vp;

import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Signature;

import fri.isp.Agent;

public class Ed25519SignatureExample {

    public static void main(String[] args) throws Exception {
        final byte[] document = "An example document".getBytes(StandardCharsets.UTF_8);
        // Generiraj ključni par
        final KeyPair key = KeyPairGenerator.getInstance("Ed25519").generateKeyPair();

        // Podpiši dokument
        final Signature signer = Signature.getInstance("Ed25519");
        signer.initSign(key.getPrivate()); // Inicializiraj za podpisovanje
        signer.update(document);
        final byte[] signature = signer.sign();
        System.out.println("Signature: " + Agent.hex(signature));

        // Preveri podpis
        final Signature verifier = Signature.getInstance("Ed25519");
        verifier.initVerify(key.getPublic());
        verifier.update(document);

        // Preveri veljavnost podpisa
        if (verifier.verify(signature)) {
            System.out.println("Valid signature."); 
        }else {
            System.err.println("Invalid signature.");
        }
    }
}
