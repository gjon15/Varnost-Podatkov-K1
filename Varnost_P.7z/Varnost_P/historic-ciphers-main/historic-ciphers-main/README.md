# Laboratorijska vaja na temo zgodovinski šifer

Za poganjanje potrebujete sodobni Python ter knjižnici `jupyter-lab` ter `matplotlib`. Namestitev knjižnjic se opravi z ukazom:

```sh
pip install --upgrade jupyterlab matplotlib
```


