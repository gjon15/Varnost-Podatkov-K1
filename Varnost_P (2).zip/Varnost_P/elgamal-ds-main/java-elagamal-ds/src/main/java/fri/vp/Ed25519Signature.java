package fri.vp;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;

import fri.isp.Agent;

public class Ed25519Signature {

    // Generate Ed25519 key pair
    public static KeyPair gen() throws Exception {
        final KeyPair key = KeyPairGenerator.getInstance("Ed25519").generateKeyPair();
        return key;
    }

    // Sign message with private key
    public static byte[] sign(PrivateKey key, byte[] message) throws Exception {
        final Signature signer = Signature.getInstance("Ed25519");
        signer.initSign(key); // Initialize with private key
        signer.update(message);
        return signer.sign();
    }

    // Verify signature with public key
    public static boolean verify(PublicKey key, byte[] message, byte[] signature) throws Exception {
        final Signature verifier = Signature.getInstance("Ed25519");
        verifier.initVerify(key);
        verifier.update(message);
        return verifier.verify(signature);
    }

    public static void main(String[] args) throws Exception {
        final byte[] document = "We would like to sign this.".getBytes(StandardCharsets.UTF_8);

        final KeyPair key = gen();

        // Save keys to files
        Files.write(Path.of("..\\ed25519.pk"), key.getPublic().getEncoded());
        Files.write(Path.of("..\\ed25519.sk"), key.getPrivate().getEncoded());

        // Sign the document
        final byte[] signature = sign(key.getPrivate(), document);

        // Output signature and save to files
        System.out.println("Signature: " + Agent.hex(signature));
        Files.write(Path.of("..\\ed25519.sig"), signature);
        Files.write(Path.of("..\\ed25519.msg"), document);

        // Verify the signature
        if (verify(key.getPublic(), document, signature)) {
            System.out.println("Valid signature.");
        } else {
            System.err.println("Invalid signature.");
        }
    }
}
