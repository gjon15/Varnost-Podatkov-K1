package fri.vp;

import fri.isp.Agent;

import java.nio.charset.StandardCharsets;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.PSSParameterSpec;

import static fri.vp.CertUtils.*;

public class RSASignatureExample {

    public static void main(String[] args) throws Exception {
        final Certificate cert = certFromFile("../cert_ana.pem"); // Naloži certifikat od Ane
        final RSAPrivateKey skAna = privateKeyFromFile("../sk_ana.pem"); // Naloži njen zasebni ključ

        // Pripravimo sporočilo za podpis in ga podpišemo z Anainim zasebnim ključem
        final String algorithm = "RSASSA-PSS";
        final String message = "A test message.";
        final byte[] pt = message.getBytes(StandardCharsets.UTF_8);

        System.out.println("Message: " + message);
        System.out.println("PT: " + Agent.hex(pt));

        // Podpisovanje
        final Signature signer = Signature.getInstance(algorithm); // Uporabimo RSASSA-PSS
        // Nastavimo parametre PSS
        signer.setParameter(new PSSParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA256, 32, 1));
        signer.initSign(skAna); // Inicializiramo podpisovalnik z Aninim zasebnim ključem
        signer.update(pt); // Posodobimo podpisovalnik s sporočilom
        final byte[] signature = signer.sign(); // Podpišemo sporočilo

        System.out.println("Signature: " + Agent.hex(signature));

        // Preverjanje
        final Signature verifier = Signature.getInstance(algorithm); // Uporabimo RSASSA-PSS
        // Nastavimo parametre PSS
        verifier.setParameter(new PSSParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA256, 32, 1));
        verifier.initVerify(cert.getPublicKey()); // Inicializiramo preverjevalnik z Aninim javnim ključem iz certifikata
        verifier.update(pt); // Posodobimo preverjevalnik s sporočilom

        // Preverimo podpis
        if (verifier.verify(signature)) {
            System.out.println("Signature valid");
        } else {
            System.err.println("Signature invalid");
        }
    }
}
