import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.interfaces.DHPublicKey;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.X509Certificate;
import java.security.spec.X509EncodedKeySpec;
import java.security.spec.XECPrivateKeySpec;
import java.security.spec.XECPublicKeySpec;

import fri.isp.Agent;
import fri.isp.Environment;

public class kolokvi2 {

    public static KeyPair gen() throws Exception{
        final KeyPairGenerator kpg = KeyPairGenerator.getInstance("DH");
        kpg.initialize(2048);
        KeyPair kp =  kpg.generateKeyPair();
        return kp;
    }

    public static void main(String[] args) throws Exception {

        final Environment env = new Environment();
        final byte[] pw = "password".getBytes();

        env.add(new Agent("ana") {
        @Override
            public void task() throws Exception {
                KeyPair pk_ana = gen();
                Key pk_A = pk_ana.getPublic();
                Key sk_a = pk_ana.getPrivate();
                send("bor", pk_A.getEncoded());

                X509EncodedKeySpec B = new X509EncodedKeySpec(receive("bor"));
                DHPublicKey pk_B = (DHPublicKey) KeyFactory.getInstance("DH").generatePublic(B);

                KeyAgreement ka = KeyAgreement.getInstance("DH");
                ka.init(sk_a);
                ka.doPhase(pk_B, true);
                byte[] sharedSicret = ka.generateSecret();

                // H(pw, idA, idB, A, B, B^a)
                byte[] skp = (pw + "Ana" + "Bor" + pk_B + pk_A + sharedSicret).getBytes();

                Mac mac = Mac.getInstance("HmacSHA3-256");
                mac.update(skp);
                byte[] h = mac.doFinal();

                byte[] pt = "Zdravo, tukaj Ana".getBytes(StandardCharsets.UTF_8);
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.ENCRYPT_MODE, h);
                byte[] ct = cipher.doFinal(pt);

                send("bor", ct);

            }
        });

        env.add(new Agent("bor") {
        @Override
            public void task() throws Exception {
                X509EncodedKeySpec A = new X509EncodedKeySpec(receive("ana"));
                DHPublicKey pk_A = (DHPublicKey) KeyFactory.getInstance("DH").generatePublic(A);

                KeyPair kp_bor = gen();
                Key pk_B = kp_bor.getPublic();
                Key sk_b = kp_bor.getPrivate();
                send("ana", pk_B.getEncoded());

                KeyAgreement ka = KeyAgreement.getInstance("DH");
                ka.init(sk_b);
                ka.doPhase(pk_A, true);

                byte[] sharedSicret = ka.generateSecret();


                byte[] skp = (pw + "Ana" + "Bor" + pk_B + pk_A + sharedSicret).getBytes();
                Mac mac = Mac.getInstance("HmacSHA3-256");
                mac.update(skp);
                byte[] h = mac.doFinal();

                byte[] ct = receive("ana");

                Mac mac1 = Mac.getInstance("AES/GCM/NoPadding");
                mac1.update(ct);


            }
        });

        // Povežemo Ano in Bora
            env.connect("ana", "bor");
        // zaženemo simulacijsko okolje
            env.start();

    }
}
